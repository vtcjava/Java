package auditorium.dynamicarray;

public class DynamicArrayImpl<T> implements DynamicArray<T> {
    public static final int DEFAULT_CAPACITY = 16;

    private Object[] values;
    private int size;

    public DynamicArrayImpl() {
        this(DEFAULT_CAPACITY);
    }

    public DynamicArrayImpl(int capacity) {
        //TODO  Elementary_Programming
    }

    @Override
    public int size() {
        //TODO  Elementary_Programming
        return size;
    }

    @Override
    public boolean isEmpty() {
        //TODO  Elementary_Programming
        return false;
    }

    @Override
    public boolean contains(T o) {
        //TODO  Elementary_Programming
        return false;
    }

    @Override
    public int indexOf(T o) {
        //TODO  Elementary_Programming
       return 0;
    }

    private int indexOfNull(){
      //TODO  Elementary_Programming
        return 0;
    }

    @Override
    public int lastIndexOf(T o) {
        //TODO  Elementary_Programming
        return 0;
    }

    @Override
    public T get(int index)  {
        //TODO  Elementary_Programming
        return null;
    }

    @Override
    public T set(int index, T element) {
        //TODO  Elementary_Programming
        return null;
    }

    @Override
    public boolean add(T e) {
        //TODO  Elementary_Programming
        return true;
    }

    @Override
    public void add(int index, T element) {

    }

    @Override
    public T remove(int index) {
        //TODO  Elementary_Programming

        return null;
    }

    @Override
    public boolean remove(T o) {
        //TODO  Elementary_Programming
        return false;
    }

    @Override
    public String toString() {
        StringBuilder buff
                = new StringBuilder("DynamicArrayImpl { size=" + size + ",\nvalues[\n");
        for (int i = 0; i < size; i++) {
            buff.append(values[i] + ",\n");
        }
        buff.append(" ]\n}");
        return buff.toString();

    }
}
