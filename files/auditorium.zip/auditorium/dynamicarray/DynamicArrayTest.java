package auditorium.dynamicarray;


public class DynamicArrayTest {
    private static DynamicArray<Integer> dynamicArray;

    public static void main(String[] args) {
        //TODO  Elementary_Programming
    }

    public static void sizeTest() {
    }

    public static void isEmptyTest() {
        //TODO: change body of implemented methods
    }

  
    public static void indexOfTest() {
        //TODO: change body of implemented methods
    }

    public static void lastIndexOfTest() {
        //TODO: change body of implemented methods
    }

    public static void getTest() {
        //TODO: change body of implemented methods
    }

    public static void setTest(int index, Integer element) {
        //TODO: change body of implemented methods
    }

    public static void addTest() {

        //TODO: change body of implemented methods
    }

    public static void addByIndexTest() {
        //TODO: change body of implemented methods
    }

    public static void removeByIndexTest() {
        //TODO: change body of implemented methods
    }


   
}
