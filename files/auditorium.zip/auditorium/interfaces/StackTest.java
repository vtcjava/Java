package auditorium.interfaces;


/**
 * Company: WeDooApps
 * Date: 11/22/15
 *
 * Created by Adam Madoyan.
 */

public class StackTest {


    public static void main(String[] args) {

        StackInterface stack = new Queue();

        Stack s1 = (Stack)stack;

        s1.test();

//
//        for (int i = 0; i < 5; i++) {
//            stack.push(i);
//        }
//
//        for (int i = 0; i < 5; i++) {
//            System.out.print(stack.pop() + " ");
//        }
//
//        System.out.println("--------------------------");
//
//        stack = new Queue();
//
////        ((auditorium_old.interfaces.StackImpl) stack).test();
//
//        for (int i = 0; i < 5; i++) {
//            stack.push(i);
//        }
//
//        for (int i = 0; i < 5; i++) {
//            System.out.print(stack.pop() + " ");
//        }
//
//        StackInterface stackInterface = new StackImpl();
//
//        System.out.println("********************");
//
//

    }


}
