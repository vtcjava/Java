package auditorium.classes;//package auditorium_old.classes;
//
//public class RectangleTest {
//
//    public static void main(String[] args) {
//        Rectangle rectangle = new Rectangle(5,2, 10, 3);
//        rectangle.printOnConsole();
//        System.out.println(rectangle);
//    }
//}
